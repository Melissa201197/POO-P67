# -*- coding: utf-8 -*-
"""
Created on Mon Nov 24 10:30:43 2025

@author: NW
"""

from datetime import datetime

class Controlador:
    def __init__(self, robot, vista):
        self.robot = robot
        self.vista = vista 
        
    def registrar_log(self, mensaje):
        tiempo = datetime.now()
        with open ("log.txt", "a", encoding = "utf-8") as archivo:
            archivo.write (f"[{tiempo}] {mensaje}\n")
            
    def encender_robot(self):
        mensaje = self.robot.encender()
        self.vista.mostrar(mensaje)
        self.registrar_log(mensaje)
        
    def apagar_robot(self):
        mensaje = self.robot.apagar()
        self.vista.mostrar(mensaje)
        self.registrar_log(mensaje)
        
    def mover_robot(self, direccion):
        mensaje = self.robot.mover(direccion)
        self.vista.mostrar(mensaje)
        self.registrar_log(mensaje)
            