# -*- coding: utf-8 -*-
"""
Created on Mon Nov 24 10:29:31 2025

@author: NW
"""

class Vista:
    def mostrar (self,mensaje):
        print(mensaje)