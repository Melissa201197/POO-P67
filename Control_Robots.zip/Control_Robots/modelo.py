# -*- coding: utf-8 -*-
"""
Created on Mon Nov 24 10:20:19 2025

@author: NW
"""

class Robot:
    def __init__(self,nombre):
        self.nombre = nombre 
        self.estado = False
        
    def encender(self):
        self.estado = True
        return (f"{self.nombre} encendido")
    
    def apagar(self):
        self.estado = False
        return (f"{self.nombre} apagado")
    
    def mover(self,direccion):
        if not self.estado:
            return (f"{self.nombre} No puede moverse porque esta apagado")
        return (f"{self.nombre} Se mueve hacia {direccion}")
    
class Robot_Explorador (Robot):
    pass

class Robot_Industrial (Robot):
    pass