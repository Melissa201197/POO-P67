# -*- coding: utf-8 -*-
"""
Created on Mon Nov 24 10:39:49 2025

@author: NW
"""

from modelo import Robot_Explorador, Robot_Industrial
from vista import Vista
from controlador import Controlador

def main():
    vista = Vista()
    
    
    explorador = Robot_Explorador("RobotExplorador")
    control1 = Controlador(explorador, vista)
    
    control1.encender_robot()
    control1.mover_robot("adelante")
    control1.mover_robot("izquierda")
    control1.apagar_robot()
    
    print()
    
    industrial = Robot_Industrial("RobotIndustrial")
    control2 = Controlador(industrial, vista)
    control2.encender_robot()
    control2.mover_robot("derecha")
    control2.apagar_robot()
    
if __name__ == "__main__":
    main()